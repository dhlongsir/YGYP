# FragmentProject_QQ
使用Fragment模仿qq效果，见博客：http://blog.csdn.net/yanzi1225627/article/details/30763555
